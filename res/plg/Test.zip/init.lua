secret = 0
print("Test plugin!")
