print(secret)
